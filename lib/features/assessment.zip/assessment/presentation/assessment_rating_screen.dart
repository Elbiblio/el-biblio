import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/constants/app_routes.dart';
import '../application/assessment_notifier.dart';

class AssessmentRatingScreen extends ConsumerStatefulWidget {
  const AssessmentRatingScreen({super.key});

  @override
  ConsumerState<AssessmentRatingScreen> createState() =>
      _AssessmentRatingScreenState();
}

class _AssessmentRatingScreenState
    extends ConsumerState<AssessmentRatingScreen> {
  int _currentIndex = 0;
  final Map<String, int> _instances = {};
  final Map<String, String> _fears = {};

  final List<Map<String, dynamic>> _instanceOptions = [
    {'value': 0, 'label': 'Never / Not yet'},
    {'value': 3, 'label': 'A few times (1-5)'},
    {'value': 10, 'label': 'Several times (6-15)'},
    {'value': 23, 'label': 'Many times (16-30)'},
    {'value': 40, 'label': 'Very often (31-50)'},
    {'value': 60, 'label': 'Consistently (51-75)'},
    {'value': 90, 'label': 'Regularly (76-100)'},
    {'value': 120, 'label': 'Frequently (100+)'},
  ];

  final List<Map<String, String>> _fearOptions = [
    {'value': 'none', 'label': 'Not yet'},
    {'value': 'some', 'label': 'Somewhat'},
    {'value': 'many', 'label': 'Many times'},
    {'value': 'overcome', 'label': "I've overcome them"},
  ];

  void _onNext() {
    final state = ref.read(assessmentProvider);
    final archetypes = state.selectedArchetypes;

    if (archetypes.isEmpty) return;

    final currentArchetype = archetypes[_currentIndex];
    final instances = _instances[currentArchetype.name];
    final fears = _fears[currentArchetype.name];

    if (instances == null || fears == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please answer both questions to continue'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    // Save current archetype's data
    ref
        .read(assessmentProvider.notifier)
        .saveArchetypeAssessment(currentArchetype.name, instances, fears);

    if (_currentIndex < archetypes.length - 1) {
      setState(() {
        _currentIndex++;
      });
    } else {
      // All done, navigate to next phase
      context.push('${AppRoutes.assessment}/path');
    }
  }

  void _onPrevious() {
    if (_currentIndex > 0) {
      setState(() {
        _currentIndex--;
      });
    } else {
      context.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    const primaryColor = Color(0xFFF4B925);
    final bgColor = isDark ? const Color(0xFF221D10) : const Color(0xFFF8F7F5);
    final textColor = isDark ? Colors.white : Colors.black87;

    final state = ref.watch(assessmentProvider);
    final archetypes = state.selectedArchetypes;
    final age = state.age;

    if (archetypes.isEmpty || age == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final currentArchetype = archetypes[_currentIndex];

    // Split and take first 3 for preview
    final strengthsList = currentArchetype.strengths
        .split(';')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
    final distortionsList = currentArchetype.distortions
        .split(';')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();

    final strengthsPreview = strengthsList.take(3).join(', ');
    final distortionsPreview = distortionsList.take(3).join(', ');

    // Calculate expected based on logic from script
    int expectedMin = 1, expectedMax = 3;
    if (age < 20) {
      expectedMin = 1;
      expectedMax = 3;
    } else if (age < 30) {
      expectedMin = 3;
      expectedMax = 8;
    } else if (age < 40) {
      expectedMin = 8;
      expectedMax = 15;
    } else if (age < 50) {
      expectedMin = 15;
      expectedMax = 25;
    } else {
      expectedMin = 25;
      expectedMax = 40;
    }

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: textColor),
          onPressed: _onPrevious,
        ),
        title: Text(
          'Archetype ${_currentIndex + 1} of ${archetypes.length}',
          style: TextStyle(
            color: textColor.withValues(alpha: 0.5),
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(
                    horizontal: 24.0, vertical: 16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header Card
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: isDark
                            ? primaryColor.withValues(alpha: 0.05)
                            : Colors.white,
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(
                            color: primaryColor.withValues(alpha: 0.2)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            currentArchetype.name,
                            style: TextStyle(
                              color: textColor,
                              fontSize: 32,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Cinzel',
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            currentArchetype.identity,
                            style: TextStyle(
                              color: textColor.withValues(alpha: 0.7),
                              fontSize: 18,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Context info
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color:
                            isDark ? Colors.grey[900] : const Color(0xFFF8F9FA),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text.rich(
                            TextSpan(
                              style: TextStyle(
                                  color: textColor.withValues(alpha: 0.8),
                                  fontSize: 14,
                                  height: 1.5),
                              children: [
                                const TextSpan(
                                    text:
                                        'Think about situations where you\'ve used the strengths of '),
                                TextSpan(
                                    text: currentArchetype.name,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold)),
                                const TextSpan(
                                    text:
                                        ' to uplift or empower others. These are recognizable through heartfelt appreciation, awards, special recognition, or mentions.'),
                              ],
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'Based on your age ($age), we\'d expect to see between $expectedMin and $expectedMax instances of using this talent.',
                            style: TextStyle(
                                color: textColor.withValues(alpha: 0.6),
                                fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 32),

                    // Instances Question
                    Text(
                      'About how many times have you empowered others through your natural abilities${strengthsPreview.isNotEmpty ? ' (e.g. $strengthsPreview)' : ''}?',
                      style: TextStyle(
                        color: textColor,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                        color: isDark ? Colors.black26 : Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                            color: primaryColor.withValues(alpha: 0.3)),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<int>(
                          isExpanded: true,
                          value: _instances[currentArchetype.name],
                          hint: Text('Select a range...',
                              style: TextStyle(
                                  color: textColor.withValues(alpha: 0.5))),
                          dropdownColor:
                              isDark ? const Color(0xFF221D10) : Colors.white,
                          icon:
                              Icon(Icons.arrow_drop_down, color: primaryColor),
                          items: _instanceOptions.map((option) {
                            return DropdownMenuItem<int>(
                              value: option['value'] as int,
                              child: Text(
                                option['label'] as String,
                                style: TextStyle(color: textColor),
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            if (value != null) {
                              setState(() {
                                _instances[currentArchetype.name] = value;
                              });
                            }
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Select the range that best matches your experience. Don\'t worry about exact numbers.',
                      style: TextStyle(
                          color: textColor.withValues(alpha: 0.5),
                          fontSize: 12),
                    ),

                    const SizedBox(height: 32),

                    // Fears Question
                    Text(
                      'Have you faced fears like ${distortionsPreview.isNotEmpty ? distortionsPreview : 'the worldly distortions'} — worldly distortions commonly associated with this archetype?',
                      style: TextStyle(
                        color: textColor,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                        color: isDark ? Colors.black26 : Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                            color: primaryColor.withValues(alpha: 0.3)),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          isExpanded: true,
                          value: _fears[currentArchetype.name],
                          hint: Text('Select an option...',
                              style: TextStyle(
                                  color: textColor.withValues(alpha: 0.5))),
                          dropdownColor:
                              isDark ? const Color(0xFF221D10) : Colors.white,
                          icon:
                              Icon(Icons.arrow_drop_down, color: primaryColor),
                          items: _fearOptions.map((option) {
                            return DropdownMenuItem<String>(
                              value: option['value'] as String,
                              child: Text(
                                option['label'] as String,
                                style: TextStyle(color: textColor),
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            if (value != null) {
                              setState(() {
                                _fears[currentArchetype.name] = value;
                              });
                            }
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 40), // Bottom padding
                  ],
                ),
              ),
            ),

            // Bottom Action
            Container(
              padding: EdgeInsets.fromLTRB(
                  24, 16, 24, 16 + MediaQuery.of(context).padding.bottom),
              decoration: BoxDecoration(
                color: bgColor.withValues(alpha: 0.95),
                border: Border(
                  top: BorderSide(
                    color: primaryColor.withValues(alpha: 0.2),
                  ),
                ),
              ),
              child: SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: _instances[currentArchetype.name] != null &&
                          _fears[currentArchetype.name] != null
                      ? _onNext
                      : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor,
                    foregroundColor: const Color(0xFF221D10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    elevation: 0,
                  ),
                  child: Text(
                    _currentIndex == archetypes.length - 1
                        ? 'Complete Assessment →'
                        : 'Next Archetype →',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
