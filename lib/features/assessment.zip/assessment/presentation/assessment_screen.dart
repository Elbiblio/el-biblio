import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/constants/app_routes.dart';
import '../domain/models/archetype.dart';
import 'widgets/interactive_compass_wheel.dart';
import '../application/assessment_notifier.dart';

class AssessmentScreen extends ConsumerStatefulWidget {
  const AssessmentScreen({super.key});

  @override
  ConsumerState<AssessmentScreen> createState() => _AssessmentScreenState();
}

class _AssessmentScreenState extends ConsumerState<AssessmentScreen> {
  List<Archetype> selectedArchetypes = [];
  Archetype? currentArchetype;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    // Custom colors based on the design
    const primaryColor = Color(0xFFF4B925);
    final bgColor = isDark ? const Color(0xFF221D10) : const Color(0xFFF8F7F5);
    final textColor = isDark ? Colors.white : Colors.black87;

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: bgColor.withValues(alpha: 0.8),
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: textColor),
          onPressed: () => context.pop(),
        ),
        title: Text(
          'Kingdom Archetypes Compass',
          style: TextStyle(
            color: textColor,
            fontSize: 18,
            fontWeight: FontWeight.bold,
            letterSpacing: -0.5,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.info_outline, color: textColor),
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Kingdom Archetypes Compass'),
                  content: const Text(
                    'The Kingdom Archetypes Compass helps identify your spiritual calling based on your strengths and potential distortions. Select up to 3 archetypes that resonate with you to discover your unique spiritual gifts.',
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Got it'),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text(
                    'Select up to 3 archetypes that resonate with you',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: textColor,
                        ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: primaryColor.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          color: primaryColor.withValues(alpha: 0.3)),
                    ),
                    child: Text(
                      'Selected: ${selectedArchetypes.length}/3',
                      style: const TextStyle(
                        color: primaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Main content area with wheel and info
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    // Interactive Compass Wheel
                    SizedBox(
                      height: 350,
                      child: Center(
                        child: InteractiveCompassWheel(
                          onArchetypeSelected: _handleArchetypeSelected,
                          selectedArchetypes: selectedArchetypes,
                        ),
                      ),
                    ),

                    // Current Archetype Info
                    if (currentArchetype != null)
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 20),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: isDark
                              ? primaryColor.withValues(alpha: 0.05)
                              : Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: primaryColor.withValues(alpha: 0.2)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  currentArchetype!.name,
                                  style: Theme.of(context)
                                      .textTheme
                                      .titleLarge
                                      ?.copyWith(
                                        color: primaryColor,
                                        fontWeight: FontWeight.bold,
                                      ),
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  '(${currentArchetype!.identity})',
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyMedium
                                      ?.copyWith(
                                        color: textColor.withValues(alpha: 0.7),
                                      ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Text(
                              'Spiritual Strengths:',
                              style: Theme.of(context)
                                  .textTheme
                                  .titleSmall
                                  ?.copyWith(
                                    color: textColor,
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              currentArchetype!.strengths,
                              style: Theme.of(context)
                                  .textTheme
                                  .bodySmall
                                  ?.copyWith(
                                    color: textColor.withValues(alpha: 0.8),
                                  ),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              'Worldly Distortions:',
                              style: Theme.of(context)
                                  .textTheme
                                  .titleSmall
                                  ?.copyWith(
                                    color: textColor,
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              currentArchetype!.distortions,
                              style: Theme.of(context)
                                  .textTheme
                                  .bodySmall
                                  ?.copyWith(
                                    color: textColor.withValues(alpha: 0.8),
                                  ),
                            ),
                          ],
                        ),
                      ),

                    // Selected Archetypes
                    if (selectedArchetypes.isNotEmpty)
                      Container(
                        margin: const EdgeInsets.all(20),
                        child: Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: selectedArchetypes.map((archetype) {
                            return Chip(
                              label: Text(archetype.name),
                              backgroundColor:
                                  primaryColor.withValues(alpha: 0.1),
                              deleteIcon: const Icon(Icons.close, size: 16),
                              onDeleted: () => _removeArchetype(archetype),
                            );
                          }).toList(),
                        ),
                      ),

                    // Bottom padding for scroll
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),

            // Bottom Action (fixed at bottom)
            Container(
              padding: EdgeInsets.fromLTRB(
                  24, 16, 24, 16 + MediaQuery.of(context).padding.bottom),
              decoration: BoxDecoration(
                color: bgColor.withValues(alpha: 0.95),
                border: Border(
                  top: BorderSide(
                    color: primaryColor.withValues(alpha: 0.2),
                  ),
                ),
              ),
              child: SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: selectedArchetypes.isNotEmpty
                      ? () {
                          // Save archetypes to state
                          ref
                              .read(assessmentProvider.notifier)
                              .setArchetypes(selectedArchetypes);
                          // Navigate to age screen
                          context.push('${AppRoutes.assessment}/age');
                        }
                      : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor,
                    foregroundColor: const Color(0xFF221D10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    elevation: 4,
                    shadowColor: primaryColor.withValues(alpha: 0.4),
                  ),
                  child: Text(
                    selectedArchetypes.isEmpty
                        ? 'Select Archetypes to Continue'
                        : 'Continue to Assessment',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _handleArchetypeSelected(Archetype archetype) {
    setState(() {
      currentArchetype = archetype;

      final newSelected = List<Archetype>.from(selectedArchetypes);
      if (newSelected.contains(archetype)) {
        newSelected.remove(archetype);
      } else if (newSelected.length < 3) {
        newSelected.add(archetype);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('You can only select up to 3 archetypes'),
          ),
        );
      }
      selectedArchetypes = newSelected;
    });
  }

  void _removeArchetype(Archetype archetype) {
    setState(() {
      final newSelected = List<Archetype>.from(selectedArchetypes);
      newSelected.remove(archetype);
      selectedArchetypes = newSelected;

      if (currentArchetype == archetype) {
        currentArchetype = null;
      }
    });
  }
}
