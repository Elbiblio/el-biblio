import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/models/archetype.dart';

class ExpectedInstances {
  final int min;
  final int max;

  const ExpectedInstances({required this.min, required this.max});
}

class ArchetypeAssessmentData {
  final int instances;
  final String fears; // 'none', 'some', 'many', 'overcome'
  final ExpectedInstances expected;
  final int maturity;

  const ArchetypeAssessmentData({
    required this.instances,
    required this.fears,
    required this.expected,
    required this.maturity,
  });

  ArchetypeAssessmentData copyWith({
    int? instances,
    String? fears,
    ExpectedInstances? expected,
    int? maturity,
  }) {
    return ArchetypeAssessmentData(
      instances: instances ?? this.instances,
      fears: fears ?? this.fears,
      expected: expected ?? this.expected,
      maturity: maturity ?? this.maturity,
    );
  }
}

class AssessmentState {
  final List<Archetype> selectedArchetypes;
  final int? age;
  final Map<String, ArchetypeAssessmentData> assessmentData;
  final String? selectedPath; // 'development', 'engagement', 'recalibration'
  final List<String> selectedTasks;

  const AssessmentState({
    this.selectedArchetypes = const [],
    this.age,
    this.assessmentData = const {},
    this.selectedPath,
    this.selectedTasks = const [],
  });

  AssessmentState copyWith({
    List<Archetype>? selectedArchetypes,
    int? age,
    Map<String, ArchetypeAssessmentData>? assessmentData,
    String? selectedPath,
    List<String>? selectedTasks,
  }) {
    return AssessmentState(
      selectedArchetypes: selectedArchetypes ?? this.selectedArchetypes,
      age: age ?? this.age,
      assessmentData: assessmentData ?? this.assessmentData,
      selectedPath: selectedPath ?? this.selectedPath,
      selectedTasks: selectedTasks ?? this.selectedTasks,
    );
  }
}

class AssessmentNotifier extends StateNotifier<AssessmentState> {
  AssessmentNotifier() : super(const AssessmentState());

  void setArchetypes(List<Archetype> archetypes) {
    state = state.copyWith(selectedArchetypes: archetypes);
  }

  void setAge(int age) {
    state = state.copyWith(age: age);
  }

  ExpectedInstances _calculateExpectedInstances(int age) {
    if (age < 20) return const ExpectedInstances(min: 1, max: 3);
    if (age < 30) return const ExpectedInstances(min: 3, max: 8);
    if (age < 40) return const ExpectedInstances(min: 8, max: 15);
    if (age < 50) return const ExpectedInstances(min: 15, max: 25);
    return const ExpectedInstances(min: 25, max: 40);
  }

  int _calculateMaturity(int age, int instances, ExpectedInstances expected) {
    final ratio = instances / expected.max;
    final baseMaturity = (ratio * 100).clamp(0.0, 100.0);
    final ageFactor = (age / 50.0).clamp(0.0, 1.0) * 20.0;
    return (baseMaturity + ageFactor).clamp(0.0, 100.0).round();
  }

  int getAverageMaturity() {
    if (state.selectedArchetypes.isEmpty || state.assessmentData.isEmpty) {
      return 0;
    }

    int totalMaturity = 0;
    int count = 0;

    for (final archetype in state.selectedArchetypes) {
      final data = state.assessmentData[archetype.name];
      if (data != null) {
        totalMaturity += data.maturity;
        count++;
      }
    }

    return count > 0 ? (totalMaturity / count).round() : 0;
  }

  String getRecommendedPath() {
    final avgMaturity = getAverageMaturity();
    return avgMaturity < 50 ? 'development' : 'recalibration';
  }

  void saveArchetypeAssessment(
      String archetypeName, int instances, String fears) {
    if (state.age == null) return;

    final expected = _calculateExpectedInstances(state.age!);
    final maturity = _calculateMaturity(state.age!, instances, expected);

    final newData =
        Map<String, ArchetypeAssessmentData>.from(state.assessmentData);
    newData[archetypeName] = ArchetypeAssessmentData(
      instances: instances,
      fears: fears,
      expected: expected,
      maturity: maturity,
    );

    state = state.copyWith(assessmentData: newData);
  }

  void setPath(String path) {
    state = state.copyWith(selectedPath: path);
  }

  void setTasks(List<String> tasks) {
    state = state.copyWith(selectedTasks: tasks);
  }

  void reset() {
    state = const AssessmentState();
  }
}

final assessmentProvider =
    StateNotifierProvider<AssessmentNotifier, AssessmentState>((ref) {
  return AssessmentNotifier();
});
